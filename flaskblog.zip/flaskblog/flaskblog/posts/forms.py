# posts/forms.py
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField, SelectField
from wtforms.validators import DataRequired, Length
from flask_wtf.file import FileField, FileAllowed

class PostForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    tag = SelectField(
        'Tag',
        choices=[('Miscellaneous', 'Miscellaneous'), ('General', 'General'), ('Review', 'Review'), ('Haiku', 'Haiku'), ('Waka', 'Waka'), ('Senryū', 'Senryū'), ('Shintaishi', 'Shintaishi (New Style)'), ('Nara Period', 'Nara Period'), ('Kamakura and Muromachi periods', 'Kamakura and Muromachi periods'), ('Edo Period', 'Edo Period'), ('Heian Period', 'Heian Period'), ('Site Maintenance', 'Site Maintenance')],
        validators=[DataRequired()], default="Miscellaneous"
    )
    content = TextAreaField('Content', validators=[DataRequired()])
    image = FileField('Add a picture', validators=[FileAllowed(['jpg', 'png'])])
    submit = SubmitField('Post')

    def validate_tag(self, tag):
        if tag is None:
            raise ValidationError("That username is taken. Please choose another.")



class CommentForm(FlaskForm):
    content = TextAreaField('Comment', validators=[DataRequired(), Length(max=150)])
    submit = SubmitField('Post')


