
from flask import render_template, request, Blueprint, flash, redirect, url_for
from flaskblog.models import Post, User
from flaskblog import db
from flaskblog.main.forms import SearchForm, SortByForm


main = Blueprint('main', __name__)

def sortFunc(e):
    return len(e.comments)

@main.route("/", methods=["GET", "POST"])
@main.route("/home", methods=["GET", "POST"])
def home():
    form = SortByForm()
    page = request.args.get('page', 1, type=int)
    
    if form.validate_on_submit():
        if form.byComments.data == False:
            posts=Post.query.order_by(Post.date_posted.desc()).paginate(page = page, per_page=10)
            return render_template('home.html', posts=posts, form=form)
        else:
            return redirect(url_for("main.home_comments"))
    posts=Post.query.order_by(Post.date_posted.desc()).paginate(page = page, per_page=10)
    return render_template('home.html', posts=posts, form=form)

@main.route("/home_comments", methods=["GET", "POST"])
def home_comments():
    #number of posts shown
    const_posts=7
    form = SortByForm()
    page = request.args.get('page', 1, type=int)
    if request.method == 'POST':
        if form.byComments.data == False:
            return redirect(url_for('main.home'))
        else:
            return redirect(url_for('main.home_comments'))
    else:
        form.byComments.data = True
        posts=Post.query.order_by(Post.date_posted.desc()).all()
        posts.sort(key=sortFunc, reverse=True)
        num = min(len(posts), (page*const_posts))
        num = (page*const_posts)
        posts_1 = posts[0:num-const_posts]
        posts_2 = posts[num-const_posts:num]
        if num == len(posts):
            is_end = True
        else:
            is_end = False
        return render_template('home_comments.html', num=num, posts_1=posts_1, posts_2=posts_2, is_end=is_end, form=form, comments=True, current_page=page)
    return render_template('home_comments.html', posts=posts, form=form)

@main.route("/about")
def about():
    return render_template('about.html', title='About')

@main.route("/search", methods=["GET", "POST"])
def search():
    form = SearchForm()
    if form.validate_on_submit():
        username = User.query.filter_by(username=form.user.data).first()
        post = Post.query.filter_by(title=form.post.data).first()
        if username:
            post = Post.query.filter_by(title=form.post.data, author=username).order_by(Post.date_posted.desc()).first()
            if post:
                #return redirect(url_for('posts.post', post_id=post.id))
                return redirect(url_for('main.page', title=form.post.data, username=form.user.data))
            else:
                if(form.post.data):
                    flash(f"No post with title {form.post.data} has been posted by {form.user.data}. Here are some other posts by {form.user.data}", "warning")
                return redirect(url_for('users.user_posts', username=username.username))
        elif post:
            #return redirect(url_for('posts.post', post_id=post.id))
            if form.user.data:
                flash(f"No user named {form.user.data} exists. Here are some other posts titled {form.post.data}", "warning")
            return redirect(url_for('main.page_title', title=form.post.data))
        else:
            flash('No user or post by that name found', 'danger')
            return redirect(url_for("main.home"))

    return render_template('search.html', title='Search', form=form)

@main.route("/page/<string:title>")
def page_title(title):
    posts=Post.query.filter_by(title=title).order_by(Post.date_posted.desc()).paginate(page = 1, per_page=25)
    return render_template('page.html', posts=posts, legend=f"Posts titled {title}")

@main.route("/page/<string:title>/<string:username>")
def page(title, username):
    user = User.query.filter_by(username=username).first()
    posts=Post.query.filter_by(title=title, author=user).order_by(Post.date_posted.desc()).paginate(page = 1, per_page=25)
    return render_template('page.html', posts=posts, legend=f"Posts by {username} titled {title}")

@main.route("/page/<string:tag>/<int:none>")
def page_tag(tag, none):
    posts=Post.query.filter_by(tag=tag).order_by(Post.date_posted.desc()).paginate(page = 1, per_page=25)
    return render_template('page.html', posts=posts, legend=f"Posts tagged with {tag}")