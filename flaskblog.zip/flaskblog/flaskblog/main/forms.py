from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, BooleanField

class SearchForm(FlaskForm):
    post = StringField('Post title', validators=[])
    user = StringField('Username', validators=[])
    submit = SubmitField('Search')

class SortByForm(FlaskForm):
    byComments = BooleanField("Sort by comments")
    submit = SubmitField('Submit')