#from flaskblog import create_app
#app = create_app()
#app.app_context().push()
#from flaskblog import db
#from flaskblog.models import User, Comment, Post
#db.drop_all()
#db.create_all()

from flaskblog import create_app

app = create_app()

if __name__ == '__main__':
    app.run(debug=True)